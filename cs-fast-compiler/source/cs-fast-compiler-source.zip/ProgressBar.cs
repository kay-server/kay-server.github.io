﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ProgressIndicatorNC
{
    public class ProgressIndicator : UserControl
    {
        private Timer tm;
        private int counter = 0;

        [DefaultValue(5)]
        public int ItemsCount { get; set; }
        [DefaultValue(5)]
        public int ItemSize { get; set; }
        [DefaultValue(50)]
        public double ItemSpeed { get; set; }
        [DefaultValue(6)]
        public int ItemDistance { get; set; }
        [DefaultValue(3)]
        public int ItemSlope { get; set; }

        public ProgressIndicator()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
            tm = new Timer();
            tm.Interval = 20;
            tm.Tick += (o, e) => { counter++; Invalidate(); };
            tm.Enabled = true;
            ItemsCount = 5;
            ItemSize = 5;
            Height = ItemSize;
            ItemSpeed = 70;
            ItemDistance = 6;
            ItemSlope = 3;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (!Enabled)
                return;

            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;

            var y = ClientRectangle.Height / 2 - ItemSize / 2;
            var cx = ClientRectangle.Width / 2;

            using (var brush = new SolidBrush(ForeColor))
                for (int i = 0; i < ItemsCount; i++)
                {
                    var x = ((i * ItemDistance + counter) % (2 * ItemSpeed) - ItemSpeed) / ItemSpeed;
                    x = Math.Tan(x * Math.PI / 2.01) / ItemSlope;
                    var xx = ClientRectangle.Width * x / 2d;
                    e.Graphics.FillRectangle(brush, cx + (float)xx, y, ItemSize, ItemSize);
                }
        }
    }
}