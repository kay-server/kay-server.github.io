﻿
namespace MultiTool
{
    partial class MainWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.close_btn = new System.Windows.Forms.Button();
            this.wordWrapSetting = new System.Windows.Forms.CheckBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Arguments = new System.Windows.Forms.TextBox();
            this.FileName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Editor = new FastColoredTextBoxNS.FastColoredTextBox();
            this.EditorContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.compileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.loadingBar = new WindowsFormsApplication265.ProgressIndicator();
            this.panel2 = new System.Windows.Forms.Panel();
            this.topMostSetting = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hideloadingbar = new System.Windows.Forms.Timer(this.components);
            this.EditorAutoCompleteMenu = new AutocompleteMenuNS.AutocompleteMenu();
            this.service = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Editor)).BeginInit();
            this.EditorContextMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // close_btn
            // 
            this.close_btn.AutoEllipsis = true;
            this.close_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.close_btn.FlatAppearance.BorderColor = System.Drawing.Color.DodgerBlue;
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue;
            this.close_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.close_btn.ForeColor = System.Drawing.Color.White;
            this.close_btn.Location = new System.Drawing.Point(3, 1);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(102, 23);
            this.close_btn.TabIndex = 0;
            this.close_btn.Text = "Compile and run";
            this.close_btn.UseVisualStyleBackColor = false;
            this.close_btn.Click += new System.EventHandler(this.COMPILE);
            // 
            // wordWrapSetting
            // 
            this.wordWrapSetting.AutoEllipsis = true;
            this.wordWrapSetting.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.wordWrapSetting.ForeColor = System.Drawing.Color.White;
            this.wordWrapSetting.Location = new System.Drawing.Point(10, 3);
            this.wordWrapSetting.Name = "wordWrapSetting";
            this.wordWrapSetting.Size = new System.Drawing.Size(89, 18);
            this.wordWrapSetting.TabIndex = 0;
            this.wordWrapSetting.Text = "Word wrap";
            this.wordWrapSetting.UseVisualStyleBackColor = true;
            this.wordWrapSetting.CheckedChanged += new System.EventHandler(this.wordWrapSetting_CheckedChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1.Controls.Add(this.panel4);
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            this.splitContainer1.Panel1.Controls.Add(this.loadingBar);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1MinSize = 1;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.topMostSetting);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Panel2.Controls.Add(this.wordWrapSetting);
            this.splitContainer1.Panel2MinSize = 1;
            this.splitContainer1.Size = new System.Drawing.Size(505, 295);
            this.splitContainer1.SplitterDistance = 269;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 2;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(5, 8);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.Editor);
            this.splitContainer2.Size = new System.Drawing.Size(495, 260);
            this.splitContainer2.SplitterDistance = 27;
            this.splitContainer2.SplitterWidth = 1;
            this.splitContainer2.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.20376F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.79625F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.20376F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.79625F));
            this.tableLayoutPanel1.Controls.Add(this.Arguments, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.FileName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(495, 27);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // Arguments
            // 
            this.EditorAutoCompleteMenu.SetAutocompleteMenu(this.Arguments, null);
            this.Arguments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.Arguments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Arguments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Arguments.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Arguments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Arguments.Location = new System.Drawing.Point(305, 3);
            this.Arguments.Name = "Arguments";
            this.Arguments.Size = new System.Drawing.Size(187, 23);
            this.Arguments.TabIndex = 7;
            // 
            // FileName
            // 
            this.EditorAutoCompleteMenu.SetAutocompleteMenu(this.FileName, null);
            this.FileName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.FileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FileName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FileName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.FileName.Location = new System.Drawing.Point(58, 3);
            this.FileName.Name = "FileName";
            this.FileName.Size = new System.Drawing.Size(186, 23);
            this.FileName.TabIndex = 3;
            this.FileName.Text = "output";
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "File:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(250, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 27);
            this.label2.TabIndex = 7;
            this.label2.Text = "Args:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Editor
            // 
            this.Editor.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.EditorAutoCompleteMenu.SetAutocompleteMenu(this.Editor, this.EditorAutoCompleteMenu);
            this.Editor.AutoIndentCharsPatterns = "\r\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\r\n^\\s*(case|default)\\s*[^:" +
    "]*(?<range>:)\\s*(?<range>[^;]+);\r\n";
            this.Editor.AutoScrollMinSize = new System.Drawing.Size(361, 182);
            this.Editor.BackBrush = null;
            this.Editor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.Editor.CaretColor = System.Drawing.Color.Gainsboro;
            this.Editor.ChangedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Editor.CharHeight = 13;
            this.Editor.CharWidth = 7;
            this.Editor.ContextMenuStrip = this.EditorContextMenu;
            this.Editor.CurrentLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Editor.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Editor.DescriptionFile = "";
            this.Editor.DisabledColor = System.Drawing.Color.Empty;
            this.Editor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Editor.Font = new System.Drawing.Font("Courier New", 9F);
            this.Editor.ForeColor = System.Drawing.Color.White;
            this.Editor.IndentBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Editor.IsReplaceMode = false;
            this.Editor.LeftBracket = '(';
            this.Editor.LeftBracket2 = '{';
            this.Editor.LineNumberColor = System.Drawing.Color.PowderBlue;
            this.Editor.Location = new System.Drawing.Point(0, 0);
            this.Editor.Name = "Editor";
            this.Editor.PaddingBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(61)))), ((int)(((byte)(61)))));
            this.Editor.Paddings = new System.Windows.Forms.Padding(0);
            this.Editor.RightBracket = ')';
            this.Editor.RightBracket2 = '}';
            this.Editor.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Editor.ServiceColors = null;
            this.Editor.ServiceLinesColor = System.Drawing.Color.DeepSkyBlue;
            this.Editor.Size = new System.Drawing.Size(495, 232);
            this.Editor.TabIndex = 5;
            this.Editor.Text = resources.GetString("Editor.Text");
            this.Editor.Zoom = 100;
            this.Editor.TextChanged += new System.EventHandler<FastColoredTextBoxNS.TextChangedEventArgs>(this.Editor_TextChanged);
            this.Editor.SelectionChanged += new System.EventHandler(this.Editor_SelectionChanged_1);
            this.Editor.Load += new System.EventHandler(this.Editor_Load);
            // 
            // EditorContextMenu
            // 
            this.EditorContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.compileToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.EditorContextMenu.Name = "EditorContextMenu";
            this.EditorContextMenu.Size = new System.Drawing.Size(144, 70);
            this.EditorContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.EditorContextMenu_Opening);
            // 
            // compileToolStripMenuItem
            // 
            this.compileToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.compileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.compileToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.compileToolStripMenuItem.Image = global::CSFastCompiler.Properties.Resources.add_row;
            this.compileToolStripMenuItem.Name = "compileToolStripMenuItem";
            this.compileToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.compileToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.compileToolStripMenuItem.Text = "Compile";
            this.compileToolStripMenuItem.Click += new System.EventHandler(this.compileToolStripMenuItem_Click_1);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.copyToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.copyToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.copyToolStripMenuItem.Image = global::CSFastCompiler.Properties.Resources.copy;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pasteToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pasteToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.pasteToolStripMenuItem.Image = global::CSFastCompiler.Properties.Resources.copy;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 8);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 260);
            this.panel4.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(500, 8);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 260);
            this.panel3.TabIndex = 0;
            // 
            // loadingBar
            // 
            this.loadingBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.loadingBar.ForeColor = System.Drawing.Color.White;
            this.loadingBar.ItemDistance = 5;
            this.loadingBar.ItemsCount = 6;
            this.loadingBar.ItemSpeed = 45D;
            this.loadingBar.Location = new System.Drawing.Point(0, 0);
            this.loadingBar.Name = "loadingBar";
            this.loadingBar.Size = new System.Drawing.Size(505, 8);
            this.loadingBar.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 268);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(505, 1);
            this.panel2.TabIndex = 0;
            // 
            // topMostSetting
            // 
            this.topMostSetting.AutoEllipsis = true;
            this.topMostSetting.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.topMostSetting.ForeColor = System.Drawing.Color.White;
            this.topMostSetting.Location = new System.Drawing.Point(105, 3);
            this.topMostSetting.Name = "topMostSetting";
            this.topMostSetting.Size = new System.Drawing.Size(89, 18);
            this.topMostSetting.TabIndex = 2;
            this.topMostSetting.Text = "Top most";
            this.topMostSetting.UseVisualStyleBackColor = true;
            this.topMostSetting.CheckedChanged += new System.EventHandler(this.topMostSetting_CheckedChanged);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(286, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "(C) DosX [2021]\r\n  Kay Software company";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.close_btn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(398, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(107, 25);
            this.panel1.TabIndex = 0;
            // 
            // hideloadingbar
            // 
            this.hideloadingbar.Enabled = true;
            this.hideloadingbar.Interval = 1000;
            this.hideloadingbar.Tick += new System.EventHandler(this.hideloadingbar_Tick);
            // 
            // EditorAutoCompleteMenu
            // 
            this.EditorAutoCompleteMenu.AllowsTabKey = true;
            this.EditorAutoCompleteMenu.AppearInterval = 30;
            this.EditorAutoCompleteMenu.Colors = ((AutocompleteMenuNS.Colors)(resources.GetObject("EditorAutoCompleteMenu.Colors")));
            this.EditorAutoCompleteMenu.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EditorAutoCompleteMenu.ImageList = null;
            this.EditorAutoCompleteMenu.Items = new string[] {
        "abstract",
        "add",
        "Add",
        "alias",
        "ArrayList",
        "as",
        "ascending",
        "async",
        "await",
        "base",
        "bool",
        "break",
        "by",
        "byte",
        "case",
        "catch",
        "catch",
        "char",
        "checked",
        "class",
        "class",
        "Console",
        "Console.BackgroundColor",
        "Console.Clear",
        "Console.ForegroundColor",
        "Console.ReadKey",
        "Console.ReadLine",
        "Console.Write",
        "Console.WriteLine",
        "Console.Title",
        "ConsoleColor",
        "const",
        "Contains",
        "continue",
        "continue",
        "Convert",
        "Convert.ToBaseString64",
        "Convert.ToBoolean",
        "Convert.ToByte",
        "Convert.ToChar",
        "Convert.ToDateTime",
        "Convert.ToDecimal",
        "Convert.ToDouble",
        "Convert.ToInt16",
        "Convert.ToInt32",
        "Convert.ToInt64",
        "Convert.ToSByte",
        "Convert.ToSingle",
        "Convert.ToString",
        "Convert.ToUInt16",
        "Convert.ToUInt32",
        "Convert.ToUInt64",
        "DateTIme",
        "DateTIme.Now",
        "DateTIme.Today",
        "DateTIme.UtcNow",
        "decimal",
        "decimal[]",
        "defult",
        "delegate",
        "Delete",
        "descending",
        "do",
        "double",
        "double[]",
        "dynamic",
        "else",
        "else",
        "else if",
        "EndsWith",
        "enum",
        "equals",
        "event",
        "explicit",
        "extern",
        "false",
        "false",
        "finally",
        "fixed",
        "float",
        "float[]",
        "for",
        "for",
        "foreach",
        "from",
        "fun",
        "get",
        "global",
        "goto",
        "group",
        "GUIhandler:",
        "if",
        "if",
        "implicit",
        "in",
        "IndexOf",
        "Insert",
        "int",
        "int[]",
        "Int16",
        "Int32",
        "Int64",
        "internal",
        "into",
        "intrface",
        "is",
        "join",
        "Join",
        "LastIndexOf",
        "Length",
        "let",
        "lock",
        "long",
        "long[]",
        "Math",
        "Math.Abs",
        "Math.Acos",
        "Math.BigMul",
        "Math.Ceiling",
        "Math.Cos",
        "Math.Cosh",
        "Math.DivRem",
        "Math.Exp",
        "Math.Floor",
        "Math.IEEERemainder",
        "Math.Log",
        "Math.Log10",
        "Math.Max",
        "Math.Min",
        "Math.Pow",
        "Math.Round",
        "Math.Sign",
        "Math.Sin",
        "Math.Sinh",
        "Math.Sqrt",
        "Math.Tan",
        "Math.Tanh",
        "Math.Truncate",
        "Microsoft.CSharp",
        "Microsoft.JScript",
        "Microsoft.VisualBasic",
        "Microsoft.VisualBasic.Compatibility",
        "Microsoft.VisualBasic.Compatibility.Data",
        "Microsoft.VisualC",
        "Microsoft.VisualC.STLCLR",
        "nameof",
        "namespace",
        "new",
        "notnull",
        "null",
        "null",
        "object",
        "object",
        "on",
        "operator",
        "orderby",
        "out",
        "override",
        "params",
        "partial",
        "pass",
        "PresentationBuildTasks",
        "PresentationCore",
        "PresentationFramework",
        "PresentationFramework.Aero",
        "presentationframework.aero2",
        "presentationframework.aerolite",
        "PresentationFramework.Classic",
        "PresentationFramework.Luna",
        "PresentationFramework.Royale",
        "private",
        "private:",
        "protected",
        "protected:",
        "public",
        "ReadAllBytes",
        "ReadAllLines",
        "ReadAllText",
        "readonly",
        "ref",
        "remove",
        "Replace",
        "return",
        "sbyte",
        "sbyte[]",
        "sealed",
        "select",
        "set",
        "short",
        "short[]",
        "single",
        "single[]",
        "sizeof",
        "Split",
        "stackalloc",
        "StartsWith",
        "static",
        "stop",
        "string",
        "string[]",
        "struct",
        "Substring",
        "switch",
        "System",
        "System.Activities",
        "System.Activities.Core.Presentation",
        "System.Activities.DurableInstancing",
        "System.Activities.Presentation",
        "System.AddIn",
        "System.AddIn.Contract",
        "System.ComponentModel.Composition",
        "System.ComponentModel.Composition.registration",
        "System.ComponentModel.DataAnnotations",
        "System.Configuration",
        "System.Configuration.Install",
        "System.Core",
        "System.Data",
        "System.Data.DataSetExtensions",
        "System.Data.Entity",
        "System.Data.Entity.Design",
        "System.Data.Linq",
        "System.Data.OracleClient",
        "System.Data.Services",
        "System.Data.Services.Client",
        "System.Data.Services.Design",
        "System.Data.SqlXml",
        "System.Deployment",
        "System.Design",
        "System.Device",
        "System.DirectoryServices",
        "System.DirectoryServices.AccountManagement",
        "System.DirectoryServices.Protocols",
        "System.Drawing",
        "System.Drawing.Design",
        "System.EnterpriseServices",
        "System.EnterpriseServices.Thunk",
        "System.EnterpriseServices.Wrapper",
        "System.IdentityModel",
        "System.IdentityModel.Selectors",
        "System.Identitymodel.services",
        "System.IO.Compression",
        "System.IO.Compression.FileSystem",
        "System.IO.Log",
        "System.Management",
        "System.Management.Instrumentation",
        "System.Messaging",
        "System.Net",
        "System.Net.Http",
        "System.Net.Http.WebRequest",
        "System.Numerics",
        "System.Printing",
        "System.Reflection.Context",
        "System.Runtime.Caching",
        "System.Runtime.DurableInstancing",
        "System.Runtime.Remoting",
        "System.Runtime.Serialization",
        "System.Runtime.Serialization.Formatters.Soap",
        "System.Security",
        "System.ServiceModel",
        "System.ServiceModel.Activation",
        "System.ServiceModel.Activities",
        "System.ServiceModel.Channels",
        "System.ServiceModel.Discovery",
        "System.ServiceModel.Routing",
        "System.ServiceModel.Web",
        "System.ServiceProcess",
        "System.Speech",
        "System.Transactions",
        "System.Web",
        "System.Web.Abstractions",
        "System.Web.ApplicationServices",
        "System.Web.DataVisualization",
        "System.Web.DataVisualization.Design",
        "System.Web.DynamicData",
        "System.Web.DynamicData.Design",
        "System.Web.Entity",
        "System.Web.Entity.Design",
        "System.Web.Extensions",
        "System.Web.Extensions.Design",
        "System.Web.Mobile",
        "System.Web.RegularExpressions",
        "System.Web.Routing",
        "System.Web.Services",
        "System.Windows",
        "System.Windows.Controls.Ribbon",
        "System.Windows.Forms",
        "System.Windows.Forms.DataVisualization",
        "System.Windows.Forms.DataVisualization.Design",
        "System.Windows.Input.Manipulations",
        "System.Windows.Presentation",
        "System.Workflow.Activities",
        "System.Workflow.ComponentModel",
        "System.Workflow.Runtime",
        "System.WorkflowServices",
        "System.Xaml",
        "System.XML",
        "System.Xml.Linq",
        "System.Xml.Serialization",
        "this",
        "this",
        "throw",
        "toFloat()",
        "toInt()",
        "ToLower",
        "toStr()",
        "ToUpper",
        "Trim",
        "true",
        "true",
        "try",
        "typeof",
        "uint",
        "uint[]",
        "ulong",
        "ulong[]",
        "unchecked",
        "unmanaged",
        "unsafe",
        "ushort",
        "ushort[]",
        "using",
        "value",
        "var",
        "var",
        "virtual",
        "void",
        "volatile",
        "when",
        "where",
        "while",
        "while",
        "with",
        "WriteAllBytes",
        "WriteAllLines",
        "WriteAllText",
        "yield",
        "",
        "AliceBlue",
        "AntiqueWhite",
        "Aqua",
        "Aquamarine",
        "Azure",
        "Beige",
        "Bisque",
        "Black",
        "BlanchedAlmond",
        "Blue",
        "BlueViolet",
        "Brown",
        "BurlyWood",
        "CadetBlue",
        "Chartreuse",
        "Chocolate",
        "Coral",
        "CornflowerBlue",
        "Cornsilk",
        "Crimson",
        "Cyan",
        "DarkBlue",
        "DarkCyan",
        "DarkGoldenrod",
        "DarkGray",
        "DarkGreen",
        "DarkKhaki",
        "DarkMagenta",
        "DarkOliveGreen",
        "DarkOrange",
        "DarkOrchid",
        "DarkRed",
        "DarkSalmon",
        "DarkSeaGreen",
        "DarkSlateBlue",
        "DarkSlateGray",
        "DarkTurquoise",
        "DarkViolet",
        "DeepPink",
        "DeepSkyBlue",
        "DimGray",
        "DodgerBlue",
        "Firebrick",
        "FloralWhite",
        "ForestGreen",
        "Fuchsia",
        "Gainsboro",
        "GhostWhite",
        "Gold",
        "Goldenrod",
        "Gray",
        "Green",
        "GreenYellow",
        "Honeydew",
        "HotPink",
        "IndianRed",
        "Indigo",
        "IsEmpty",
        "IsKnownColor",
        "IsNamedColor",
        "IsSystemColor",
        "Ivory",
        "Khaki",
        "Lavender",
        "LavenderBlush",
        "LawnGreen",
        "LemonChiffon",
        "LightBlue",
        "LightCoral",
        "LightCyan",
        "LightGoldenrodYellow",
        "LightGray",
        "LightGreen",
        "LightPink",
        "LightSalmon",
        "LightSeaGreen",
        "LightSkyBlue",
        "LightSlateGray",
        "LightSteelBlue",
        "LightYellow",
        "Lime",
        "LimeGreen",
        "Linen",
        "Magenta",
        "Maroon",
        "MediumAquamarine",
        "MediumBlue",
        "MediumOrchid",
        "MediumPurple",
        "MediumSeaGreen",
        "MediumSlateBlue",
        "MediumSpringGreen",
        "MediumTurquoise",
        "MediumVioletRed",
        "MidnightBlue",
        "MintCream",
        "MistyRose",
        "Moccasin",
        "NavajoWhite",
        "Navy",
        "OldLace",
        "Olive",
        "OliveDrab",
        "Orange",
        "OrangeRed",
        "Orchid",
        "PaleGoldenrod",
        "PaleGreen",
        "PaleTurquoise",
        "PaleVioletRed",
        "PapayaWhip",
        "PeachPuff",
        "Peru",
        "Pink",
        "Plum",
        "PowderBlue",
        "Purple",
        "Red",
        "RosyBrown",
        "RoyalBlue",
        "SaddleBrown",
        "Salmon",
        "SandyBrown",
        "SeaGreen",
        "SeaShell",
        "Sienna",
        "Silver",
        "SkyBlue",
        "SlateBlue",
        "SlateGray",
        "Snow",
        "SpringGreen",
        "SteelBlue",
        "Tan",
        "Teal",
        "Thistle",
        "Tomato",
        "Transparent",
        "Turquoise",
        "Violet",
        "Wheat",
        "White",
        "WhiteSmoke",
        "Yellow",
        "YellowGreen"};
            this.EditorAutoCompleteMenu.LeftPadding = 1;
            this.EditorAutoCompleteMenu.MaximumSize = new System.Drawing.Size(270, 250);
            this.EditorAutoCompleteMenu.TargetControlWrapper = null;
            this.EditorAutoCompleteMenu.ToolTipDuration = 2000;
            // 
            // service
            // 
            this.service.Enabled = true;
            this.service.Interval = 750;
            this.service.Tick += new System.EventHandler(this.autosave_Tick);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(505, 295);
            this.Controls.Add(this.splitContainer1);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Editor)).EndInit();
            this.EditorContextMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.CheckBox wordWrapSetting;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private WindowsFormsApplication265.ProgressIndicator loadingBar;
        private System.Windows.Forms.Timer hideloadingbar;
        private FastColoredTextBoxNS.FastColoredTextBox Editor;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox Arguments;
        private System.Windows.Forms.TextBox FileName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public AutocompleteMenuNS.AutocompleteMenu EditorAutoCompleteMenu;
        private System.Windows.Forms.Timer service;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox topMostSetting;
        private System.Windows.Forms.ContextMenuStrip EditorContextMenu;
        private System.Windows.Forms.ToolStripMenuItem compileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
    }
}

