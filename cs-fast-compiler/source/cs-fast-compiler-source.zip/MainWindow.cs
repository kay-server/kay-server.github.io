﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.VisualBasic;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Drawing.Drawing2D;

namespace MultiTool
{
    public partial class MainWindow : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = false)]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, string lParam);
        public MainWindow()
        {
            InitializeComponent(); // init components
            MainWindow.SendMessage(this.FileName.Handle, 5377, 0, "Output file name");
            MainWindow.SendMessage(this.Arguments.Handle, 5377, 0, "Command line args");
        }
        private void Editor_SelectionChanged(object sender, EventArgs e)
        {
            if (this.Editor.SelectionLength <= 0)
            {
                this.copyToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.copyToolStripMenuItem.Enabled = true;
            }
        }
        private void MainWindow_Load(object sender, EventArgs e)
        {
            try
            {
                string[] Configuration = System.IO.File.ReadAllLines("autosave.cfg");
                FileName.Text = Configuration[0];
                string args = Configuration[1];
                args = args.Replace("|~notext!0~|", "");
                Arguments.Text = args;

            }
            catch (Exception)
            {

               
            }
        }
        private void COMPILE(object sender, EventArgs e)
        {
            COMPILE_CODE();
        }
        private void COMPILE_CODE()
        {
            FileName.Enabled = false;
            Arguments.Enabled = false;
            Editor.Enabled = false;
            Editor.IsChanged = false;
            loadingBar.Visible = true;
            hideloadingbar.Enabled = true;
            try
            {
                File.WriteAllText("args.cfg", this.Arguments.Text);
                File.WriteAllText("tmp.cs", this.Editor.Text);
                string str = FileName.Text.Replace(".exe", null).Replace(" ", null);
                if (str.Trim() == "")
                {
                    MessageBox.Show("The project name cannot be empty.", "[Fast-Compiler]", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    updatetitle();
                    Process.Start("service.bat", str);
                }
            }
            catch (Exception)
            {
            }
        }
        private void updatetitle()
        {
            if (FileName.Text.Trim() != "")
            {
                Text = string.Concat(FileName.Text, " — C# Fast-Compiler");
            }
            else
            {
                Text = "C# Fast-Compiler";
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(Editor.SelectedText);
        }

        int tick = 0;
        private void hideloadingbar_Tick(object sender, EventArgs e)
        {
            tick++;
            if (tick == 3) {
                Editor.Focus();
                loadingBar.Visible = false;
                tick = 0;
                hideloadingbar.Enabled = false;
                FileName.Enabled = true;
                Arguments.Enabled = true;
                Editor.Enabled = true;
            }
        }

        private void wordWrapSetting_CheckedChanged(object sender, EventArgs e)
        {
            Editor.WordWrap = wordWrapSetting.Checked;
        }

        private void autosave_Tick(object sender, EventArgs e)
        {
            try
            {
                string text = this.Arguments.Text;
                if (text.Trim() == "")
                {
                    text = "|~notext!0~|";
                }
                File.WriteAllText("autosave.cfg", string.Concat(this.FileName.Text, "\n", text));
                this.updatetitle();
                if (Clipboard.ContainsText())
                {
                    this.pasteToolStripMenuItem.Enabled = true;
                }
                else
                {
                    this.pasteToolStripMenuItem.Enabled = false;
                }
            }
            catch (Exception)
            {
            }
        }

        private void topMostSetting_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = topMostSetting.Checked;
        }

        private void Editor_Load(object sender, EventArgs e)
        {
        }

        EllipseStyle ellipseStyle = new EllipseStyle();
        EllipseStyleSyntax ellipseStyleSyntax = new EllipseStyleSyntax();
        EllipseStyleSyntaxLogic ellipseStyleSyntaxLogic = new EllipseStyleSyntaxLogic();

        private void Editor_TextChanged(object sender, TextChangedEventArgs e)
        {
            e.ChangedRange.ClearStyle(new Style[] { this.ellipseStyle });
            e.ChangedRange.SetStyle(this.ellipseStyle, "\\busing\\b", RegexOptions.IgnoreCase);
            e.ChangedRange.SetStyle(this.ellipseStyleSyntax, "\\bclass\\b", RegexOptions.IgnoreCase);
            e.ChangedRange.SetStyle(this.ellipseStyleSyntaxLogic, "\\bvoid\\b", RegexOptions.IgnoreCase);
            e.ChangedRange.SetStyle(this.ellipseStyleSyntaxLogic, "\\bnamespace\\b", RegexOptions.IgnoreCase);
        }

        private void compileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            COMPILE_CODE();
        }

        private void Editor_SelectionChanged_1(object sender, EventArgs e)
        {
            if (this.Editor.SelectionLength <= 0)
            {
                this.copyToolStripMenuItem.Enabled = false;
            }
            else
            {
                this.copyToolStripMenuItem.Enabled = true;
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Editor.Paste();
        }

        private void EditorContextMenu_Opening(object sender, CancelEventArgs e)
        {

        }
    }
    internal class EllipseStyle : Style
    {
        public EllipseStyle()
        {
        }

        public override void Draw(Graphics gr, Point position, Range range)
        {
            Rectangle rectangle = new Rectangle(position, Style.GetSizeOfRange(range));
            GraphicsPath roundedRectangle = Style.GetRoundedRectangle(rectangle, 4);
            gr.DrawPath(Pens.DarkSlateBlue, roundedRectangle);
        }
    }
    internal class EllipseStyleSyntax : Style
    {
        public EllipseStyleSyntax()
        {
        }

        public override void Draw(Graphics gr, Point position, Range range)
        {
            Rectangle rectangle = new Rectangle(position, Style.GetSizeOfRange(range));
            rectangle.Inflate(1, 0);
            GraphicsPath roundedRectangle = Style.GetRoundedRectangle(rectangle, 2);
            gr.DrawPath(Pens.DarkSlateGray, roundedRectangle);
        }
    }
    internal class EllipseStyleSyntaxLogic : Style
    {
        public EllipseStyleSyntaxLogic()
        {
        }

        public override void Draw(Graphics gr, Point position, Range range)
        {
            Rectangle rectangle = new Rectangle(position, Style.GetSizeOfRange(range));
            rectangle.Inflate(1, 1);
            GraphicsPath roundedRectangle = Style.GetRoundedRectangle(rectangle, 3);
            gr.DrawPath(Pens.DarkSlateGray, roundedRectangle);
        }
    }
}
