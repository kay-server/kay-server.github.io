﻿// Coded by DosX

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace MultiTool
{
    public static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles(); // system styles
            Application.SetCompatibleTextRenderingDefault(false);

            string window_title = "C# Fast-Compiler (libraryes loading...)";
            Form MainWindow = new MainWindow() {
                MinimumSize = new System.Drawing.Size(440, 310),
                //MaximumSize = new System.Drawing.Size(950, 650),
                Text = window_title,
                MaximizeBox = true
            }; Application.Run(MainWindow);
        }
    }
}